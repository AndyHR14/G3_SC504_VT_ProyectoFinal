<?php
return [
  1 => ['id'=>1, 'nombre'=>'Pecera 60L',         'img'=>BASE_URL.'/public/img/productos/pecera60.jpg',          'precio'=>45000],
  2 => ['id'=>2, 'nombre'=>'Filtro interno',     'img'=>BASE_URL.'/public/img/productos/filtro-interno.jpg',     'precio'=>18000],
  3 => ['id'=>3, 'nombre'=>'Filtro canister',    'img'=>BASE_URL.'/public/img/productos/filtro-canister.jpeg',   'precio'=>75000],
  4 => ['id'=>4, 'nombre'=>'Alimento Bettas',    'img'=>BASE_URL.'/public/img/productos/betta-food.png',         'precio'=>2500],
  5 => ['id'=>5, 'nombre'=>'Alimento Tropical',  'img'=>BASE_URL.'/public/img/productos/tropical-food.jpg',      'precio'=>4200],
  6 => ['id'=>6, 'nombre'=>'Grava blanca',       'img'=>BASE_URL.'/public/img/productos/grava-blanca.jpg',       'precio'=>3500],
  7 => ['id'=>7, 'nombre'=>'Plantas vivas',      'img'=>BASE_URL.'/public/img/productos/plantas.jpg',            'precio'=>6000],
  8 => ['id'=>8, 'nombre'=>'Calentador 100W',    'img'=>BASE_URL.'/public/img/productos/calentador-100w.jpg',    'precio'=>22000],
  9 => ['id'=>9, 'nombre'=>'Bomba de aire',      'img'=>BASE_URL.'/public/img/productos/bomba-aire.jpg',         'precio'=>12000],
 10 => ['id'=>10,'nombre'=>'Lámpara LED',        'img'=>BASE_URL.'/public/img/productos/lampara-led.jpg',        'precio'=>18000],
 11 => ['id'=>11,'nombre'=>'Acondicionador agua','img'=>BASE_URL.'/public/img/productos/acondicionador-agua.jpg','precio'=>5200],
 12 => ['id'=>12,'nombre'=>'Red para peces',     'img'=>BASE_URL.'/public/img/productos/red-peces.jpg',          'precio'=>2500],
];
